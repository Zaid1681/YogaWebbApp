import "./Navbar.css";
import React from "react";

const Navbar = () => {
  return (
    <div>
      <nav className="navbar navbar-dark bg-dark fixed-top ">
        <div className="container-fluid navbar-container">
          <a className="navbar-brand " style={{marginTop:"-60px", color:"white",}} href="\">
            YOGA
          </a>
          {/* <a className="navbar-brand" href="#">
            Offcanvas dark navbar
          </a> */}
          <div className="navlinks-container ">
            <ul className="text-light navlinks list d-flex ">
              <a href="#home">
                <li>Home</li>
              </a>
              <a href="#about">
                <li>About</li>
              </a>
              {/* <a href="/">
                <li>Blogs</li>
              </a> */}
              <a href="#tut">
                <li>Tutoring</li>
              </a>
              <a href="/learn">
                <li>Start Learning</li>``
              </a>

              {/* <li>
                {" "}
                <button className="btn btn-primary">Premium</button>{" "}
              </li> */}
            </ul>
          </div>
          <button
            className="navbar-toggler offcanvas-end offcanvas-toggle"
            type="button"
            data-bs-toggle="offcanvas"
            data-bs-target="#offcanvasDarkNavbar"
            aria-controls="offcanvasDarkNavbar"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div
            className=" offcanvas offcanvas-end text-bg-dark"
            // tabindex="-1"
            id="offcanvasDarkNavbar"
            aria-labelledby="offcanvasDarkNavbarLabel"
          >
            <div className="offcanvas-header">
              <h5 className="offcanvas-title" id="offcanvasDarkNavbarLabel">
                Dark offcanvas
              </h5>
              <button
                type="button"
                className="btn-close btn-close-white"
                data-bs-dismiss="offcanvas"
                aria-label="Close"
              ></button>
            </div>

            {/* Navbar for a larger container */}

            {/* offcanvas Body on particular  */}
            <div className="offcanvas-body">
              <ul className="navbar-nav justify-content-end flex-grow-1 pe-3">
                <li className="nav-item">
                  <a className="nav-link active" aria-current="page" href="/">
                    Home
                  </a>
                </li>
                <li className="nav-item">
                  <a className="nav-link" href="/about">
                    About
                  </a>
                </li>
                <li className="nav-item">
                  <a className="nav-link" href="#">
                    Blogs
                  </a>
                </li>
                <li className="nav-item">
                  <a className="nav-link" href="#">
                    Tutoring
                  </a>
                </li>
                <li className="nav-item">
                  <a className="nav-link" href="/learn">
                    Start Learning
                  </a>
                </li>
              </ul>
              <form action="" className="d-flex">
                {/* <button
                  className="btn btn-primary "
                  style={{
                    margin: "auto",
                    textAlign: "center",
                    width: "200px",
                  }}
                >
                  Premium
                </button> */}
              </form>
            </div>
          </div>
        </div>
      </nav>
    </div>
  );
};

export default Navbar;
