import React from "react";
import "./SectionTitle.css";

const SectionTitle = ({ sectionTitle, sectionSub }) => {
  return (
    <div className="titleContainer">
      <h1 className="sectionTitle">{sectionTitle}</h1>
      <h3 className="sectionSubtitle">{sectionSub}</h3>
    </div>
  );
};

export default SectionTitle;
