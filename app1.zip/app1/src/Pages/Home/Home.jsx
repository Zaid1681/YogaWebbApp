import React from "react";
import "./Home.css";
// import {Yoga_home}  from "../../assets/Yoga_home.png"
import { Link } from "react-router-dom";
import About from "../About/About";
import TutoringSection from "../TutoringSection/TutoringSection";
import Tutors from "../Tutor/Tutors";

const Home = () => {
  return (
    <div>
      <div className="homeContainer d-flex p-3 " id="home "> 
        <div className="homeInfo   d-flex flex-column p-4 my-auto gap-3  ">
          <div className="homeinfo_data d-flex flex-column  justify-content-right gap-4 pb-2 ">
            <h1 className="homeInfo_heading" id="head1">YOGA TRAINER</h1>
            <h4 className="homeInfo_subheading" id="head2">REVITALIZE YOUR SOUL AND BODY</h4>
          </div>
          <Link to="/learn">
            <div className="homeinfo_button" id="head3">
              <button className="btn btn-primary">Start Learning</button>
            </div>
          </Link>
        </div>
      </div>
      <About />
      <TutoringSection />
      <Tutors />
    </div>
  );
};

export default Home;
