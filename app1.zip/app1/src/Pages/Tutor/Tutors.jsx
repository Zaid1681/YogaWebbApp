import React from "react";
import "./Tutors.css";
import SectionTitle from "../../Components/SectionTitle";

const Tutors = () => {
  return (
    <div className="Container tutorContainer">
      <div className="tutorDetails">
        <SectionTitle
          sectionTitle="Meet Our Instructors"
          sectionSub="Challenge your strength. Stretch your body. Breathe easy. Our team of world-class instructors will empower you to grow and achieve all of your fitness and wellness goals."
        />
      </div>
      <div className="row">
        <div className="col-lg-3">
          <img src="/tut1.jpg" alt="" />
          <h2>Ashley </h2>
          <p>Yoga Instructor</p>
        </div>
        <div className="col-lg-3">
          <img src="/tut2.jpg" alt="" />
          <h2>John</h2>
          <p>Fitness Instructor</p>
        </div>
        <div className="col-lg-3">
          <img src="/tut3.jpg" alt="" />
          <h2>Jade </h2>
          <p>Mindfullness Instructor</p>
        </div>
        <div className="col-lg-3">
          <img src="/tut4.jpg" alt="" />
          <h2>Jackie </h2>
          <p>Yoga Instructor</p>
        </div>
      </div>
    </div>
  );
};

export default Tutors;
