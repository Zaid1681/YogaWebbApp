import React from "react";
import "./TutoringSection.css";

const TutoringSection = () => {
  return (
    <div className="tutoringSection " id="tut">
      <div className="tutoringDetails">
        {/* tutoring details */}
        {/* title */}
        <h1 className="tutoringTitle">FIT FOR YOUR LIFESTYLE</h1>
        {/* Details */}
        <h3 className="tutoringSubtitle">
          Wake up with a sunrise meditation, sweat it out with lunchtime HIIT,
          or unwind with an evening flow. You’ll find movement for every mood
          with classes sorted by time, style, and skill level.
        </h3>
        <button className="btn btn-primary">Explore Classes</button>
        {/* Buttons */}
      </div>
      <div className="tutoringImage">
        <img src="/yog2.jpg" alt="" />
      </div>
    </div>
  );
};

export default TutoringSection;
