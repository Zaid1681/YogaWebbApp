import React from "react";
import "./About.css";
import SectionTitle from "../../Components/SectionTitle";
import { FiArrowRightCircle } from "react-icons/fi";
// import {BiRightArrow} from

const About = () => {
  return (
    <div className="aboutContainer " id="about">
      <SectionTitle
        sectionTitle="About"
        sectionSub="Yoga is a group of physical, mental, and spiritual practices or
        disciplines which originated in ancient India and aim to control and
        still the mind, recognizing a detached witness-consciousness untouched
        by the mind and mundane suffering"
      />
      <div className="gridContainer container ">
        <div className="row" style={{ gap: "5rem", justifyContent: "center" }}>
          <div className="gridItem col-lg-3 ">
            <img src="/yog9.jpg" alt="" />
            <div className="aboutLinks">
              {/* title */}
              <h3 className="aboutTitle">Yoga</h3>
              <FiArrowRightCircle />

              {/* icon */}
              {/* <BiRightArrow /> */}
            </div>
            {/* subtitile */}
            <p>Yoga improves strength, balance and flexibility</p>
          </div>
          <div className="gridItem col-lg-3">
            <img src="/yog7.jpg" alt="" />
            <div className="aboutLinks">
              {/* title */}
              <h3>Mindfullness</h3>
              <FiArrowRightCircle />
              {/* icon */}
            </div>
            {/* subtitile */}
            <p>
              Find meditations for relaxation, creativity, and restful sleep.
            </p>
          </div>
          <div className="gridItem col-lg-3">
            <img src="/yog8.jpg" alt="" />
            <div className="aboutLinks">
              {/* title */}
              <h3>Fitness</h3>
              <FiArrowRightCircle />

              {/* icon */}
            </div>
            {/* subtitile */}
            <p>
              Train on your time with Strength, Barre, Pilates, HIIT, Core, and
              more.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;
{
  /* <div className="aboutData">
        <h5>Media Pipe</h5>
        <p>
        MediaPipe Solutions allows you to apply machine learning (ML) solutions to your apps, with a framework that lets you configure pre-built processing pipelines to get immediate, engaging, and useful output for your users. You can even customize these solutions using Model Maker to update the default models.


        </p>
      </div>

      <div className="aboutData">
        <h5>React Js</h5>
        <p>
          React is a frontend library used to create frontend library
        </p>
      </div> */
}
