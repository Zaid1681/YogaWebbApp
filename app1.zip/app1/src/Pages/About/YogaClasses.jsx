import React from "react";
import "./About.css";

const YogaClasses = () => {
  return (
    <div>
      <div className="gridContainer container ">
        <div className="row" style={{ gap: "5rem", justifyContent: "center" }}>
          <div className="gridItem col-lg-3 ">
            <img src="/yog9.jpg" alt="" />
            <div className="aboutLinks">
              {/* title */}
              <h3 className="aboutTitle">Yoga</h3>
              <FiArrowRightCircle />

              {/* icon */}
              {/* <BiRightArrow /> */}
            </div>
            {/* subtitile */}
            <p>
              Lorem ipsum dolor sit amet consectetur, adipisicing elit. Dolorem,
              culpa.
            </p>
          </div>
          <div className="gridItem col-lg-3">
            <img src="/yog7.jpg" alt="" />
            <div className="aboutLinks">
              {/* title */}
              <h3>Mindfullness</h3>
              <FiArrowRightCircle />
              {/* icon */}
            </div>
            {/* subtitile */}
            <p>
              Find meditations for relaxation, creativity, and restful sleep.
            </p>
          </div>
          <div className="gridItem col-lg-3">
            <img src="/yog8.jpg" alt="" />
            <div className="aboutLinks">
              {/* title */}
              <h3>Fitness</h3>
              <FiArrowRightCircle />

              {/* icon */}
            </div>
            {/* subtitile */}
            <p>
              Train on your time with Strength, Barre, Pilates, HIIT, Core, and
              more.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default YogaClasses;
