import React from 'react'

const Start = ({setInput}) => {
  return (
    <div>Start</div>
  )
}

export default Start